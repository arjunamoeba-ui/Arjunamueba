
Penjualan App - Flutter + SQLite (Offline) - Extended
====================================================

Fitur yang disertakan di project ini:
1. Login sederhana (Owner/Kasir) - credentials disimpan aman (secure storage)
2. Master Produk - tambah/edit/hapus + stok
3. Transaksi - pilih produk, qty, total & laba otomatis, stok berkurang otomatis
4. Laporan penjualan harian/bulanan, export CSV
5. Dashboard dengan grafik penjualan & laba (fl_chart)
6. Cetak struk via Bluetooth (stub/sample code included, requires pairing & device setup)

File ini adalah project skeleton. Untuk mendapatkan APK, ikuti langkah build.

Build APK (lokal):
1. Install Flutter SDK: https://flutter.dev/docs/get-started/install
2. Extract project folder and cd to it.
3. Run: `flutter pub get`
4. Run: `flutter build apk --release`
5. APK akan ada di: `build/app/outputs/flutter-apk/app-release.apk`

Build via GitHub Actions:
- Push project ke repo GitHub. Workflow file is included (.github/workflows/build-apk.yml).
- Actions akan menghasilkan artifact app-release.apk.

Notes:
- Bluetooth printing requires granting Bluetooth permissions and pairing with printer. On newer Android versions, additional permissions and manifest entries are required.
- For production release: sign the APK with keystore; instructions & key.properties sample included.
