
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../db.dart';
import 'package:intl/intl.dart';

class AddTransaksi extends StatefulWidget {
  @override
  _AddTransaksiState createState() => _AddTransaksiState();
}
class _AddTransaksiState extends State<AddTransaksi> {
  int? selectedId;
  int harga = 0;
  int modal = 0;
  int stok = 0;
  final qtyC = TextEditingController(text: '1');

  @override
  Widget build(BuildContext context) {
    final db = Provider.of<AppDatabase>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Tambah Transaksi')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            FutureBuilder(
              future: db.listProduk(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return CircularProgressIndicator();
                final list = snapshot.data as List<Map<String,dynamic>>;
                return DropdownButton<int?>(
                  value: selectedId,
                  hint: Text('Pilih Produk'),
                  isExpanded: true,
                  items: list.map((p) => DropdownMenuItem<int?>(
                    value: p['id'] as int?,
                    child: Text('${p['nama']} (Harga: ${p['harga']} | Stok: ${p['stok']})'),
                  )).toList(),
                  onChanged: (v) {
                    setState(() {
                      selectedId = v;
                      final p = list.firstWhere((e) => e['id'] == v);
                      harga = p['harga'] ?? 0;
                      modal = p['modal'] ?? 0;
                      stok = p['stok'] ?? 0;
                    });
                  },
                );
              },
            ),
            TextField(controller: qtyC, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'Qty')),
            SizedBox(height:12),
            ElevatedButton(onPressed: () async {
              final q = int.tryParse(qtyC.text) ?? 1;
              if (selectedId==null) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Pilih produk dulu')));
                return;
              }
              if (q > stok) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Stok tidak cukup')));
                return;
              }
              final total = q * harga;
              final laba = (harga - modal) * q;
              final now = DateTime.now().toIso8601String();
              await db.insertTransaksi({
                'tanggal': now,
                'idProduk': selectedId,
                'qty': q,
                'total': total,
                'laba': laba,
              });
              Navigator.pop(context);
            }, child: Text('Simpan Transaksi')),
          ],
        ),
      ),
    );
  }
}
