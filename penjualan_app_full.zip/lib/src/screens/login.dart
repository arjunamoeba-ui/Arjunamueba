
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:provider/provider.dart';
import '../db.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final userC = TextEditingController();
  final passC = TextEditingController();
  final storage = FlutterSecureStorage();
  bool loading = false;

  void login() async {
    setState(() => loading = true);
    final db = Provider.of<AppDatabase>(context, listen: false);
    final user = await db.getUser(userC.text.trim(), passC.text.trim());
    if (user == null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Login gagal')));
    } else {
      // save minimal session
      await storage.write(key: 'username', value: user['username']);
      await storage.write(key: 'role', value: user['role']);
      Navigator.pushReplacementNamed(context, '/home');
    }
    setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            TextField(controller: userC, decoration: InputDecoration(labelText: 'Username')),
            TextField(controller: passC, decoration: InputDecoration(labelText: 'Password'), obscureText: true),
            SizedBox(height:12),
            ElevatedButton(onPressed: loading?null: login, child: loading? CircularProgressIndicator(color: Colors.white): Text('Login')),
          ],
        ),
      ),
    );
  }
}
