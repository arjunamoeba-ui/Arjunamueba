
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../db.dart';
import 'package:intl/intl.dart';

class TransaksiList extends StatefulWidget {
  @override
  _TransaksiListState createState() => _TransaksiListState();
}
class _TransaksiListState extends State<TransaksiList> {
  @override
  Widget build(BuildContext context) {
    final db = Provider.of<AppDatabase>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Daftar Transaksi')),
      body: FutureBuilder(
        future: db.listTransaksi(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          final list = snapshot.data as List<Map<String,dynamic>>;
          if (list.isEmpty) return Center(child: Text('Belum ada transaksi'));
          return ListView.builder(
            itemCount: list.length,
            itemBuilder: (context, i) {
              final t = list[i];
              return ListTile(
                title: Text('ID: ${t['id']} - Tgl: ${DateFormat.yMd().add_Hms().format(DateTime.parse(t['tanggal']))}'),
                subtitle: Text('Qty: ${t['qty']} | Total: ${t['total']} | Laba: ${t['laba']}'),
              );
            },
          );
        },
      ),
    );
  }
}
