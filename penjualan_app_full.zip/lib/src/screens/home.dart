
import 'package:flutter/material.dart';
import 'produk_list.dart';
import 'add_produk.dart';
import 'transaksi_list.dart';
import 'add_transaksi.dart';
import 'dashboard.dart';
import 'laporan.dart';
import 'print_stub.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Penjualan Offline - Home')),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProdukList())), child: Text('Master Produk')),
              ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddProduk())), child: Text('Tambah Produk')),
              ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TransaksiList())), child: Text('Daftar Transaksi')),
              ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AddTransaksi())), child: Text('Tambah Transaksi')),
              ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DashboardScreen())), child: Text('Dashboard')),
              ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LaporanScreen())), child: Text('Laporan & Export')),
              ElevatedButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PrintStub())), child: Text('Cetak Struk (Bluetooth)')),
            ],
          ),
        ),
      ),
    );
  }
}
