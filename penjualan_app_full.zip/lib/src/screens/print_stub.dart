
import 'package:flutter/material.dart';

class PrintStub extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Cetak Struk (Bluetooth)')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            Text('Fungsi cetak struk memerlukan printer Bluetooth yang sudah dipairing.'),
            SizedBox(height:12),
            Text('Contoh penggunaan: gunakan plugin seperti flutter_bluetooth_serial atau blue_thermal_printer. Code contoh dan setup ada di README.'),
            SizedBox(height:12),
            ElevatedButton(onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Ini hanya stub. Implementasi printer butuh device runtime.')));
            }, child: Text('Test Print (Stub)')),
          ],
        ),
      ),
    );
  }
}
