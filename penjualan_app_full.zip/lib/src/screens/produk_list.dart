
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../db.dart';

class ProdukList extends StatefulWidget {
  @override
  _ProdukListState createState() => _ProdukListState();
}
class _ProdukListState extends State<ProdukList> {
  @override
  Widget build(BuildContext context) {
    final db = Provider.of<AppDatabase>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Daftar Produk')),
      body: FutureBuilder(
        future: db.listProduk(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          final list = snapshot.data as List<Map<String,dynamic>>;
          if (list.isEmpty) return Center(child: Text('Belum ada produk'));
          return ListView.builder(
            itemCount: list.length,
            itemBuilder: (context, i) {
              final p = list[i];
              return ListTile(
                title: Text(p['nama'] ?? ''),
                subtitle: Text('Harga: ${p['harga']} | Stok: ${p['stok']}'),
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  IconButton(icon: Icon(Icons.edit), onPressed: () async {
                    // simple edit: navigate to add screen with values
                    await Navigator.push(context, MaterialPageRoute(builder: (_) => AddProduk(editId: p['id'], initial: p)));
                    setState((){});
                  }),
                  IconButton(icon: Icon(Icons.delete), onPressed: () async {
                    await db.deleteProduk(p['id']);
                    setState((){});
                  }),
                ]),
              );
            },
          );
        },
      ),
    );
  }
}
