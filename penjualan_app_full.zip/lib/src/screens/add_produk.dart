
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../db.dart';

class AddProduk extends StatefulWidget {
  final int? editId;
  final Map<String,dynamic>? initial;
  AddProduk({this.editId, this.initial});
  @override
  _AddProdukState createState() => _AddProdukState();
}
class _AddProdukState extends State<AddProduk> {
  final _formKey = GlobalKey<FormState>();
  final kodeC = TextEditingController();
  final namaC = TextEditingController();
  final hargaC = TextEditingController();
  final modalC = TextEditingController();
  final stokC = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (widget.initial != null) {
      kodeC.text = widget.initial!['kode'] ?? '';
      namaC.text = widget.initial!['nama'] ?? '';
      hargaC.text = (widget.initial!['harga'] ?? '').toString();
      modalC.text = (widget.initial!['modal'] ?? '').toString();
      stokC.text = (widget.initial!['stok'] ?? '').toString();
    }
  }

  @override
  Widget build(BuildContext context) {
    final db = Provider.of<AppDatabase>(context);
    return Scaffold(
      appBar: AppBar(title: Text(widget.editId==null? 'Tambah Produk':'Edit Produk')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(controller: kodeC, decoration: InputDecoration(labelText: 'Kode Produk')),
              TextFormField(controller: namaC, decoration: InputDecoration(labelText: 'Nama Produk')),
              TextFormField(controller: hargaC, decoration: InputDecoration(labelText: 'Harga'), keyboardType: TextInputType.number),
              TextFormField(controller: modalC, decoration: InputDecoration(labelText: 'Modal'), keyboardType: TextInputType.number),
              TextFormField(controller: stokC, decoration: InputDecoration(labelText: 'Stok'), keyboardType: TextInputType.number),
              SizedBox(height:12),
              ElevatedButton(onPressed: () async {
                final row = {
                  'kode': kodeC.text,
                  'nama': namaC.text,
                  'harga': int.tryParse(hargaC.text) ?? 0,
                  'modal': int.tryParse(modalC.text) ?? 0,
                  'stok': int.tryParse(stokC.text) ?? 0,
                };
                if (widget.editId==null) {
                  await db.insertProduk(row);
                } else {
                  await db.updateProduk(row, widget.editId!);
                }
                Navigator.pop(context);
              }, child: Text('Simpan')),
            ],
          ),
        ),
      ),
    );
  }
}
