
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../db.dart';
import 'package:intl/intl.dart';

class LaporanScreen extends StatefulWidget {
  @override
  _LaporanScreenState createState() => _LaporanScreenState();
}
class _LaporanScreenState extends State<LaporanScreen> {
  DateTimeRange? range;

  @override
  Widget build(BuildContext context) {
    final db = Provider.of<AppDatabase>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Laporan & Export')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            ElevatedButton(onPressed: () async {
              final now = DateTime.now();
              final start = DateTime(now.year, now.month, 1);
              final end = DateTime(now.year, now.month+1, 0, 23,59,59);
              final total = await db.totalPenjualanBetween(start.toIso8601String(), end.toIso8601String());
              final laba = await db.totalLabaBetween(start.toIso8601String(), end.toIso8601String());
              showDialog(context: context, builder: (_) => AlertDialog(
                title: Text('Ringkasan Bulan Ini'),
                content: Text('Total Penjualan: \$${total}\nTotal Laba: \$${laba}'),
                actions: [TextButton(onPressed: ()=>Navigator.pop(context), child: Text('OK'))],
              ));
            }, child: Text('Ringkasan Bulan Ini')),
            SizedBox(height:12),
            ElevatedButton(onPressed: () async {
              final fp = await db.exportTransaksiCSV();
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Export berhasil: $fp')));
            }, child: Text('Export Transaksi ke CSV')),
          ],
        ),
      ),
    );
  }
}
