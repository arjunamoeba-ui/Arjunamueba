
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../db.dart';
import 'package:fl_chart/fl_chart.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}
class _DashboardScreenState extends State<DashboardScreen> {
  List<BarChartGroupData> barGroups = [];

  @override
  void initState() {
    super.initState();
    loadData();
  }
  void loadData() async {
    final db = Provider.of<AppDatabase>(context, listen: false);
    final rows = await db.produkTerlaris();
    // map to bar groups (top 5)
    final data = rows.take(5).toList();
    setState(() {
      barGroups = List.generate(data.length, (i) => BarChartGroupData(
        x: i,
        barRods: [BarChartRodData(toY: (data[i]['total_qty'] ?? 0).toDouble(), width: 15)],
      ));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Dashboard')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            Text('Produk Terlaris (Top 5)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            SizedBox(height: 12),
            if (barGroups.isEmpty) CircularProgressIndicator() else SizedBox(height:200, child: BarChart(BarChartData(barGroups: barGroups))),
          ],
        ),
      ),
    );
  }
}
