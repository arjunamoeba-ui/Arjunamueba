
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class AppDatabase {
  final Database db;
  AppDatabase._(this.db);

  static Future<AppDatabase> create() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'penjualan_app.db');
    final db = await openDatabase(path, version: 1, onCreate: (db, ver) async {
      await db.execute('''
        CREATE TABLE tblUsers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT UNIQUE,
          role TEXT,
          password TEXT
        );
      ''');
      await db.execute('''
        CREATE TABLE tblProduk (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          kode TEXT,
          nama TEXT,
          harga INTEGER,
          modal INTEGER,
          stok INTEGER
        );
      ''');
      await db.execute('''
        CREATE TABLE tblTransaksi (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tanggal TEXT,
          idProduk INTEGER,
          qty INTEGER,
          total INTEGER,
          laba INTEGER,
          FOREIGN KEY(idProduk) REFERENCES tblProduk(id)
        );
      ''');
      // Insert sample user (username: admin, password: admin123) - for demo only
      await db.insert('tblUsers', {'username': 'admin', 'role': 'owner', 'password':'admin123'});
    });
    return AppDatabase._(db);
  }

  // User auth
  Future<Map<String,dynamic>?> getUser(String username, String password) async {
    final res = await db.query('tblUsers', where: 'username = ? AND password = ?', whereArgs: [username, password]);
    if (res.isEmpty) return null;
    return res.first;
  }

  // Produk CRUD
  Future<int> insertProduk(Map<String, dynamic> row) => db.insert('tblProduk', row);
  Future<List<Map<String,dynamic>>> listProduk() => db.query('tblProduk', orderBy: 'id DESC');
  Future<int> updateProduk(Map<String, dynamic> row, int id) => db.update('tblProduk', row, where: 'id = ?', whereArgs: [id]);
  Future<int> deleteProduk(int id) => db.delete('tblProduk', where: 'id = ?', whereArgs: [id]);

  // Transaksi
  Future<int> insertTransaksi(Map<String, dynamic> row) async {
    // when inserting transaksi, decrement stock
    final idProduk = row['idProduk'] as int;
    final qty = row['qty'] as int;
    await db.rawUpdate('UPDATE tblProduk SET stok = stok - ? WHERE id = ?', [qty, idProduk]);
    return db.insert('tblTransaksi', row);
  }
  Future<List<Map<String,dynamic>>> listTransaksi() => db.query('tblTransaksi', orderBy: 'id DESC');

  // Reports
  Future<int> totalPenjualanBetween(String startIso, String endIso) async {
    final res = await db.rawQuery('SELECT SUM(total) as s FROM tblTransaksi WHERE tanggal BETWEEN ? AND ?', [startIso, endIso]);
    return res.first['s'] == null ? 0 : (res.first['s'] as int);
  }

  Future<int> totalLabaBetween(String startIso, String endIso) async {
    final res = await db.rawQuery('SELECT SUM(laba) as s FROM tblTransaksi WHERE tanggal BETWEEN ? AND ?', [startIso, endIso]);
    return res.first['s'] == null ? 0 : (res.first['s'] as int);
  }

  Future<List<Map<String,dynamic>>> produkTerlaris() async {
    return await db.rawQuery('SELECT p.nama, SUM(t.qty) as total_qty FROM tblTransaksi t JOIN tblProduk p ON t.idProduk = p.id GROUP BY p.nama ORDER BY total_qty DESC LIMIT 10');
  }

  // Export CSV: returns file path
  Future<String> exportTransaksiCSV() async {
    final rows = await db.query('tblTransaksi', orderBy: 'id DESC');
    final header = 'id,tanggal,idProduk,qty,total,laba\n';
    final csv = StringBuffer();
    csv.write(header);
    for (var r in rows) {
      csv.writeln('${r['id']},${r['tanggal']},${r['idProduk']},${r['qty']},${r['total']},${r['laba']}');
    }
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/transaksi_export.csv');
    await file.writeAsString(csv.toString());
    return file.path;
  }
}
